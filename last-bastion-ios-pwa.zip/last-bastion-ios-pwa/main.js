import { LastBastionCore } from './core/gameCore.js';

const SAVE_KEY = 'lb-mobile-prototype-save-v1';
const core = new LastBastionCore();
const els = {
  tabs: [...document.querySelectorAll('.tab')],
  panels: [...document.querySelectorAll('.tab-panel')],
  dayValue: document.getElementById('day-value'),
  populationValue: document.getElementById('population-value'),
  moraleValue: document.getElementById('morale-value'),
  defenseValue: document.getElementById('defense-value'),
  resourceGrid: document.getElementById('resource-grid'),
  overview: document.getElementById('overview-content'),
  survivorList: document.getElementById('survivor-list'),
  buildingList: document.getElementById('building-list'),
  gateContent: document.getElementById('gate-content'),
  logList: document.getElementById('log-list'),
  nextDayBtn: document.getElementById('next-day-btn'),
  saveStatus: document.getElementById('save-status'),
  exportBtn: document.getElementById('export-btn'),
  importInput: document.getElementById('import-input'),
  resetBtn: document.getElementById('reset-btn'),
  helpBtn: document.getElementById('help-btn'),
  helpDialog: document.getElementById('help-dialog'),
  closeHelpBtn: document.getElementById('close-help-btn')
};

function resourceCard(label, value) {
  return `
    <div class="card resource-card">
      <span class="label">${label}</span>
      <span class="value">${value}</span>
    </div>
  `;
}

function statBadge(text, tone = '') {
  return `<span class="badge ${tone}">${text}</span>`;
}

function progress(value) {
  const safeValue = Math.max(0, Math.min(100, value));
  return `<div class="progress"><span style="width:${safeValue}%"></span></div>`;
}

function setStatus(text) {
  els.saveStatus.textContent = text;
}

function roleLabel(roles, id) {
  return roles.find(x => x.id === id)?.label || id;
}

function exportSave() {
  const raw = localStorage.getItem(SAVE_KEY);
  if (!raw) {
    setStatus('Dışa aktarılacak kayıt bulunamadı.');
    return;
  }
  const blob = new Blob([raw], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `last-bastion-save-day-${core.state.day}.json`;
  link.click();
  URL.revokeObjectURL(url);
  setStatus('Kayıt dosyası dışa aktarıldı.');
}

async function importSave(file) {
  if (!file) return;
  const text = await file.text();
  const parsed = JSON.parse(text);
  if (!parsed || typeof parsed !== 'object' || parsed.version !== 1) {
    throw new Error('Uyumlu kayıt dosyası değil.');
  }
  localStorage.setItem(SAVE_KEY, JSON.stringify(parsed));
  core.state = parsed;
  render();
  setStatus(`Kayıt içe alındı. Gün ${core.state.day}.`);
}

function renderOverview(model) {
  const summary = model.summary;
  const riskText = summary.infected > 0 ? 'Enfeksiyon riski yüksek' : 'Enfeksiyon düşük';
  els.overview.innerHTML = `
    <div class="list-row">
      <h3>Stratejik Durum</h3>
      <div class="badge-row">
        ${statBadge(`${summary.alive} kişi`, 'ok')}
        ${statBadge(`${summary.infected} enfekte`, summary.infected ? 'danger' : 'ok')}
        ${statBadge(`${summary.injured} yaralı`, summary.injured ? 'warning' : 'ok')}
        ${statBadge(`Kişi başı ${summary.foodPressure} yemek`, summary.foodPressure < 2 ? 'warning' : 'ok')}
      </div>
      <div class="muted">${riskText}. Bu sürüm iPhone ana ekrandan tam ekran açılacak şekilde optimize edildi.</div>
    </div>
    <div class="list-row">
      <h3>Oturum Bilgisi</h3>
      <div class="badge-row">
        ${statBadge(`Kayıtlı gün ${model.day}`, 'ok')}
        ${statBadge(`${summary.builtCount} bina`, summary.builtCount ? 'ok' : 'warning')}
        ${statBadge(`Savunma ${model.stats.defense}`, model.stats.defense < 25 ? 'warning' : 'ok')}
      </div>
      <div class="muted">Her hareketten sonra kayıt otomatik tutulur. İstersen kayıt dosyasını dışa aktarabilirsin.</div>
    </div>
  `;
}

function renderSurvivors(model) {
  els.survivorList.innerHTML = model.survivors.map(person => `
    <div class="list-row">
      <div>
        <h3>${person.name}</h3>
        <div class="muted">${person.trait} · Rol: ${roleLabel(model.roles, person.role)}</div>
      </div>
      <div class="badge-row">
        ${statBadge(`Sağlık ${person.health}`, person.health < 40 ? 'danger' : person.health < 65 ? 'warning' : 'ok')}
        ${statBadge(`Moral ${person.morale}`, person.morale < 40 ? 'danger' : person.morale < 65 ? 'warning' : 'ok')}
        ${person.infected ? statBadge(`Enfekte · ${person.infectionCountdown} gün`, 'danger') : ''}
      </div>
      ${progress(person.health)}
      <label class="muted" for="assign-${person.id}">Görev ata</label>
      <select id="assign-${person.id}" class="assignment-select" data-id="${person.id}">
        ${model.roles.map(role => `
          <option value="${role.id}" ${role.id === person.role ? 'selected' : ''}>${role.label}</option>
        `).join('')}
      </select>
      <div class="badge-row">
        ${statBadge(`Çiftlik ${person.skills.farm}`)}
        ${statBadge(`Atölye ${person.skills.workshop}`)}
        ${statBadge(`Klinik ${person.skills.clinic}`)}
        ${statBadge(`Güvenlik ${person.skills.security}`)}
      </div>
    </div>
  `).join('');

  els.survivorList.querySelectorAll('select[data-id]').forEach(select => {
    select.addEventListener('change', () => {
      render(core.assignRole(select.dataset.id, select.value));
      setStatus('Görev değişikliği kaydedildi.');
    });
  });
}

function renderBuildings(model) {
  els.buildingList.innerHTML = model.buildingDefs.map(building => {
    const built = model.buildings[building.id];
    const costText = Object.entries(building.cost).map(([k, v]) => `${v} ${k}`).join(' · ');
    return `
      <div class="list-row">
        <div>
          <h3>${building.name}</h3>
          <div class="muted">${building.description}</div>
        </div>
        <div class="badge-row">
          ${built ? statBadge('İnşa edildi', 'ok') : statBadge(costText)}
        </div>
        <div class="row-actions">
          <button class="secondary-btn" ${built ? 'disabled' : ''} data-build="${building.id}">
            ${built ? 'Hazır' : 'İnşa Et'}
          </button>
        </div>
      </div>
    `;
  }).join('');

  els.buildingList.querySelectorAll('[data-build]').forEach(button => {
    button.addEventListener('click', () => {
      render(core.build(button.dataset.build));
      setStatus('Bina aksiyonu kaydedildi.');
    });
  });
}

function renderGate(model) {
  const candidate = model.gateCandidate;
  els.gateContent.innerHTML = `
    <div class="list-row">
      <div>
        <h3>${candidate.name}</h3>
        <div class="muted">${candidate.trait} · Kapıda bekliyor</div>
      </div>
      <div class="badge-row">
        ${statBadge(`Sağlık ${candidate.health}`, candidate.health < 45 ? 'warning' : 'ok')}
        ${statBadge(`Moral ${candidate.morale}`, candidate.morale < 40 ? 'warning' : 'ok')}
        ${candidate.infected ? statBadge(`Enfekte riski`, 'danger') : statBadge('Temiz görünüyor', 'ok')}
      </div>
      <div class="row-actions">
        <button class="primary-btn" id="accept-gate">Kabul Et</button>
        <button class="danger-btn" id="reject-gate">Reddet</button>
      </div>
    </div>
  `;

  document.getElementById('accept-gate').addEventListener('click', () => {
    render(core.acceptGateCandidate());
    setStatus('Kapı kararı kaydedildi.');
  });
  document.getElementById('reject-gate').addEventListener('click', () => {
    render(core.rejectGateCandidate());
    setStatus('Kapı kararı kaydedildi.');
  });
}

function renderLogs(model) {
  els.logList.innerHTML = model.logs.map(item => `<div class="list-row"><div class="muted">${item}</div></div>`).join('');
}

function renderResources(model) {
  const resources = model.resources;
  els.resourceGrid.innerHTML = [
    ['Yiyecek', resources.food],
    ['Parça', resources.parts],
    ['İlaç', resources.meds],
    ['Enerji', resources.energy],
    ['Kapak', resources.caps],
    ['Binalar', Object.values(model.buildings).filter(Boolean).length]
  ].map(([label, value]) => resourceCard(label, value)).join('');
}

function render(model = core.getViewModel()) {
  els.dayValue.textContent = model.day;
  els.populationValue.textContent = model.summary.alive;
  els.moraleValue.textContent = model.stats.morale;
  els.defenseValue.textContent = model.stats.defense;

  renderResources(model);
  renderOverview(model);
  renderSurvivors(model);
  renderBuildings(model);
  renderGate(model);
  renderLogs(model);
}

els.nextDayBtn.addEventListener('click', () => {
  render(core.nextDay());
  setStatus(`Gün ${core.state.day} kaydedildi.`);
});

els.exportBtn.addEventListener('click', exportSave);
els.importInput.addEventListener('change', async (event) => {
  try {
    await importSave(event.target.files?.[0]);
  } catch (error) {
    setStatus(error?.message || 'Kayıt içe alınamadı.');
  } finally {
    event.target.value = '';
  }
});

els.resetBtn.addEventListener('click', () => {
  const ok = confirm('Kayıt sıfırlansın mı?');
  if (!ok) return;
  render(core.reset());
  setStatus('Yeni oyun başlatıldı.');
});

els.helpBtn.addEventListener('click', () => els.helpDialog.showModal());
els.closeHelpBtn.addEventListener('click', () => els.helpDialog.close());
els.helpDialog.addEventListener('click', (event) => {
  const rect = els.helpDialog.getBoundingClientRect();
  const inside = event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
  if (!inside) els.helpDialog.close();
});

els.tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    els.tabs.forEach(x => x.classList.toggle('is-active', x === tab));
    els.panels.forEach(panel => {
      panel.classList.toggle('is-active', panel.dataset.panel === tab.dataset.tab);
    });
  });
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {});
  });
}

window.lastBastionCore = core;
setStatus(`Oyun yüklendi. Gün ${core.state.day}.`);
render();
