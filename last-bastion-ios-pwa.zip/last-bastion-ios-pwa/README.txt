LAST BASTION – iPhone/iPad Web App (PWA)

Bu paket Safari'de açılıp Ana Ekrana Ekle ile uygulama gibi çalışır.

KULLANIM
1) Bu klasörü bir statik hosting'e yükle.
   En kolay seçenekler:
   - Netlify Drag & Drop
   - GitHub Pages
   - Vercel
2) iPhone/iPad üzerinde Safari ile aç.
3) Paylaş > Ana Ekrana Ekle.
4) Oyun ikonundan tam ekran aç.

ÖZELLİKLER
- iOS ana ekran ikonu
- Standalone / tam ekran PWA görünümü
- Offline cache (service worker)
- localStorage ile otomatik kayıt
- Kayıt dışa/içe aktarma

SINIR
- Bu bir IPA/App Store paketi değildir.
- Gerçek native iOS app için Xcode + Apple Developer sertifikası gerekir.
