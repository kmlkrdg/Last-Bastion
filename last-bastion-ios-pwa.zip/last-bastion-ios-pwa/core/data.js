export const NAMES = [
  'Kemal', 'Mira', 'Cem', 'Lena', 'Atlas', 'Jade', 'Ozan', 'Selin',
  'Bora', 'Nora', 'Deniz', 'Kaan', 'Aylin', 'Riva', 'Mert', 'Ada'
];

export const TRAITS = [
  'Doktor', 'Mühendis', 'Çiftçi', 'Güvenlik', 'Aşçı', 'İyimser', 'Paranoyak', 'Yaralı'
];

export const ROLES = [
  { id: 'idle', label: 'Serbest' },
  { id: 'farm', label: 'Çiftlik' },
  { id: 'workshop', label: 'Atölye' },
  { id: 'clinic', label: 'Klinik' },
  { id: 'security', label: 'Güvenlik' }
];

export const BUILDINGS = [
  { id: 'farm', name: 'Çiftlik', cost: { parts: 12, energy: 4 }, description: 'Her gün yiyecek üretir.' },
  { id: 'workshop', name: 'Atölye', cost: { parts: 16, energy: 4 }, description: 'Parça ve hurda ekonomisini güçlendirir.' },
  { id: 'clinic', name: 'Klinik', cost: { parts: 14, meds: 6 }, description: 'Yaralı ve enfekte kişileri stabilize eder.' },
  { id: 'security', name: 'Güvenlik', cost: { parts: 18, caps: 8 }, description: 'Saldırı riskini ve kayıpları azaltır.' }
];
