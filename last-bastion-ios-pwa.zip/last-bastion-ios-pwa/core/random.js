export function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function randFrom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

export function chance(value) {
  return Math.random() < value;
}

export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
