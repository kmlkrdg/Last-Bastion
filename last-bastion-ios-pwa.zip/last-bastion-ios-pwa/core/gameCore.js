import { BUILDINGS, NAMES, ROLES, TRAITS } from './data.js';
import { chance, clamp, randFrom, randInt } from './random.js';

const SAVE_KEY = 'lb-mobile-prototype-save-v1';

function makeSurvivor(id, forcedTrait = null) {
  const trait = forcedTrait || randFrom(TRAITS);
  const skills = {
    farm: randInt(10, 65),
    workshop: randInt(10, 65),
    clinic: randInt(10, 65),
    security: randInt(10, 65),
  };

  if (trait === 'Doktor') skills.clinic = randInt(55, 90);
  if (trait === 'Mühendis') skills.workshop = randInt(55, 90);
  if (trait === 'Çiftçi') skills.farm = randInt(55, 90);
  if (trait === 'Güvenlik') skills.security = randInt(55, 90);

  const survivor = {
    id,
    name: randFrom(NAMES) + ' #' + id,
    trait,
    role: 'idle',
    health: randInt(55, 95),
    morale: randInt(45, 80),
    infected: chance(0.08),
    infectionCountdown: null,
    hungryDays: 0,
    skills
  };

  if (survivor.infected) {
    survivor.infectionCountdown = randInt(2, 4);
    survivor.health = randInt(35, 70);
  }

  if (trait === 'Yaralı') {
    survivor.health = randInt(25, 55);
  }

  return survivor;
}

function createInitialState() {
  const survivors = [
    makeSurvivor(1, 'Doktor'),
    makeSurvivor(2, 'Mühendis'),
    makeSurvivor(3, 'Çiftçi'),
    makeSurvivor(4, 'Güvenlik'),
    makeSurvivor(5, 'İyimser')
  ].map(s => ({ ...s, infected: false, infectionCountdown: null }));

  return {
    version: 1,
    day: 1,
    nextId: 6,
    resources: {
      food: 28,
      parts: 24,
      meds: 10,
      energy: 18,
      caps: 14
    },
    stats: {
      morale: 58,
      defense: 22
    },
    buildings: {
      farm: false,
      workshop: false,
      clinic: false,
      security: false
    },
    survivors,
    gateCandidate: makeSurvivor(99),
    logs: [
      'Üs kuruldu. İlk ekip duvarların içinde.',
      'Kaynaklar sınırlı. Her gün bir karar.',
      'Kapı açık. Dışarıda her zaman biri var.'
    ]
  };
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

export class LastBastionCore {
  constructor() {
    this.state = this.load() || createInitialState();
  }

  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (parsed?.version !== 1) return null;
      return parsed;
    } catch {
      return null;
    }
  }

  save() {
    localStorage.setItem(SAVE_KEY, JSON.stringify(this.state));
  }

  reset() {
    this.state = createInitialState();
    this.save();
    return this.getViewModel();
  }

  getViewModel() {
    const state = this.state;
    return {
      ...clone(state),
      buildingDefs: clone(BUILDINGS),
      roles: clone(ROLES),
      summary: this.getSummary()
    };
  }

  getSummary() {
    const alive = this.state.survivors.length;
    const infected = this.state.survivors.filter(s => s.infected).length;
    const injured = this.state.survivors.filter(s => s.health < 45).length;
    const foodPressure = alive === 0 ? 0 : Math.round((this.state.resources.food / Math.max(alive, 1)) * 10) / 10;
    return {
      alive,
      infected,
      injured,
      foodPressure,
      builtCount: Object.values(this.state.buildings).filter(Boolean).length
    };
  }

  addLog(message) {
    this.state.logs.unshift(`[Gün ${this.state.day}] ${message}`);
    this.state.logs = this.state.logs.slice(0, 80);
  }

  generateGateCandidate() {
    this.state.gateCandidate = makeSurvivor(this.state.nextId + 90);
  }

  acceptGateCandidate() {
    if (!this.state.gateCandidate) return this.getViewModel();
    const newcomer = { ...this.state.gateCandidate, id: this.state.nextId++ };
    this.state.survivors.push(newcomer);
    this.addLog(`${newcomer.name} üsse kabul edildi.`);
    this.generateGateCandidate();
    this.save();
    return this.getViewModel();
  }

  rejectGateCandidate() {
    const candidate = this.state.gateCandidate;
    if (candidate) this.addLog(`${candidate.name} kapıdan geri çevrildi.`);
    this.generateGateCandidate();
    this.state.stats.morale = clamp(this.state.stats.morale - 2, 0, 100);
    this.save();
    return this.getViewModel();
  }

  assignRole(id, role) {
    const survivor = this.state.survivors.find(x => x.id === Number(id));
    if (!survivor) return this.getViewModel();

    if (role !== 'idle' && !this.state.buildings[role]) {
      this.addLog(`${survivor.name} için ${role} atanamadı; bina yok.`);
      this.save();
      return this.getViewModel();
    }

    survivor.role = role;
    this.addLog(`${survivor.name} → ${ROLES.find(r => r.id === role)?.label || role}`);
    this.save();
    return this.getViewModel();
  }

  build(buildingId) {
    const def = BUILDINGS.find(x => x.id === buildingId);
    if (!def || this.state.buildings[buildingId]) return this.getViewModel();

    const canAfford = Object.entries(def.cost).every(([key, value]) => (this.state.resources[key] || 0) >= value);
    if (!canAfford) {
      this.addLog(`${def.name} inşası için kaynak yetersiz.`);
      this.save();
      return this.getViewModel();
    }

    Object.entries(def.cost).forEach(([key, value]) => {
      this.state.resources[key] -= value;
    });

    this.state.buildings[buildingId] = true;
    this.addLog(`${def.name} inşa edildi.`);
    this.recalculateDefense();
    this.save();
    return this.getViewModel();
  }

  recalculateDefense() {
    const guards = this.state.survivors.filter(s => s.role === 'security');
    const baseDefense = guards.reduce((sum, s) => sum + Math.round(s.skills.security / 6), 0);
    this.state.stats.defense = clamp(
      12 + baseDefense + (this.state.buildings.security ? 18 : 0),
      0,
      100
    );
  }

  processFood() {
    const people = this.state.survivors;
    const foodNeeded = people.length * 2;
    const available = this.state.resources.food;
    const consumed = Math.min(foodNeeded, available);
    this.state.resources.food -= consumed;

    if (consumed < foodNeeded) {
      const deficit = foodNeeded - consumed;
      const impacted = Math.min(people.length, Math.ceil(deficit / 2));
      [...people]
        .sort((a, b) => a.health - b.health)
        .slice(0, impacted)
        .forEach(person => {
          person.health = clamp(person.health - randInt(4, 10), 0, 100);
          person.morale = clamp(person.morale - randInt(5, 12), 0, 100);
          person.hungryDays += 1;
        });
      this.state.stats.morale = clamp(this.state.stats.morale - 6 - deficit, 0, 100);
      this.addLog(`Yiyecek yetmedi. ${deficit} puanlık açık oluştu.`);
    } else {
      people.forEach(person => {
        person.hungryDays = 0;
        person.morale = clamp(person.morale + 1, 0, 100);
      });
      this.state.stats.morale = clamp(this.state.stats.morale + 2, 0, 100);
    }
  }

  processAssignments() {
    const assigned = role => this.state.survivors.filter(s => s.role === role);
    const farmWorkers = assigned('farm');
    const workshopWorkers = assigned('workshop');
    const clinicWorkers = assigned('clinic');

    if (this.state.buildings.farm && farmWorkers.length) {
      const total = farmWorkers.reduce((sum, s) => sum + Math.round(s.skills.farm / 18), 0) + randInt(2, 4);
      this.state.resources.food += total;
      this.addLog(`Çiftlik üretimi: +${total} yiyecek.`);
    }

    if (this.state.buildings.workshop && workshopWorkers.length) {
      const parts = workshopWorkers.reduce((sum, s) => sum + Math.round(s.skills.workshop / 24), 0) + randInt(1, 3);
      const caps = workshopWorkers.reduce((sum, s) => sum + Math.round(s.skills.workshop / 40), 0);
      this.state.resources.parts += parts;
      this.state.resources.caps += caps;
      this.addLog(`Atölye üretimi: +${parts} parça, +${caps} kapak.`);
    }

    if (this.state.buildings.clinic && clinicWorkers.length) {
      const healing = clinicWorkers.reduce((sum, s) => sum + Math.round(s.skills.clinic / 20), 0) + randInt(1, 3);
      [...this.state.survivors]
        .sort((a, b) => a.health - b.health)
        .slice(0, Math.max(1, clinicWorkers.length))
        .forEach(person => {
          person.health = clamp(person.health + healing, 0, 100);
          person.morale = clamp(person.morale + 2, 0, 100);
        });

      if (this.state.resources.meds > 0) {
        this.state.resources.meds -= 1;
      }
      this.addLog(`Klinik müdahalesi: yaralılar toparlandı.`);
    }
  }

  processInfections() {
    const clinicBonus = this.state.buildings.clinic ? 1 : 0;
    const clinicWorkers = this.state.survivors.filter(s => s.role === 'clinic').length;

    for (const person of [...this.state.survivors]) {
      if (!person.infected) continue;

      const decay = randInt(10, 20) - clinicBonus - Math.min(clinicWorkers, 2);
      person.health = clamp(person.health - decay, 0, 100);
      person.morale = clamp(person.morale - 8, 0, 100);
      person.infectionCountdown = (person.infectionCountdown ?? randInt(2, 4)) - 1;

      if (person.infectionCountdown <= 0 || person.health <= 0) {
        this.state.survivors = this.state.survivors.filter(x => x.id !== person.id);
        this.state.stats.morale = clamp(this.state.stats.morale - 12, 0, 100);
        this.addLog(`${person.name} enfeksiyona yenik düştü.`);
        continue;
      }

      if (chance(0.12) && this.state.survivors.length > 1) {
        const targets = this.state.survivors.filter(x => x.id !== person.id && !x.infected);
        const target = targets[Math.floor(Math.random() * targets.length)];
        if (target) {
          target.infected = true;
          target.infectionCountdown = randInt(2, 4);
          target.health = clamp(target.health - randInt(5, 12), 0, 100);
          this.addLog(`${target.name} enfekte biriyle temas etti.`);
        }
      }
    }
  }

  processAttacks() {
    this.recalculateDefense();
    const dayPressure = Math.min(0.45, this.state.day * 0.012);
    const risk = dayPressure + (this.state.buildings.security ? -0.08 : 0.06) + (this.state.stats.morale < 35 ? 0.06 : 0);

    if (!chance(Math.max(0.08, risk))) return;

    const attackPower = randInt(12, 55) + Math.round(this.state.day * 1.7);
    const defense = this.state.stats.defense;
    if (defense >= attackPower) {
      this.state.resources.parts = Math.max(0, this.state.resources.parts - randInt(0, 3));
      this.addLog(`Saldırı püskürtüldü. Savunma ${defense}, tehdit ${attackPower}.`);
      return;
    }

    const loss = Math.max(1, Math.round((attackPower - defense) / 10));
    this.state.resources.food = Math.max(0, this.state.resources.food - randInt(2, 6));
    this.state.resources.parts = Math.max(0, this.state.resources.parts - randInt(1, 5));
    this.state.stats.morale = clamp(this.state.stats.morale - randInt(5, 12), 0, 100);

    const vulnerable = [...this.state.survivors].sort((a, b) => a.health - b.health);
    vulnerable.slice(0, Math.min(loss, vulnerable.length)).forEach(person => {
      person.health = clamp(person.health - randInt(10, 24), 0, 100);
    });

    this.addLog(`Saldırı üsse zarar verdi. Savunma ${defense}, tehdit ${attackPower}.`);
  }

  cleanupDeaths() {
    const before = this.state.survivors.length;
    this.state.survivors = this.state.survivors.filter(person => person.health > 0);
    const lost = before - this.state.survivors.length;
    if (lost > 0) {
      this.state.stats.morale = clamp(this.state.stats.morale - lost * 8, 0, 100);
      this.addLog(`${lost} kişi gün sonunda kaybedildi.`);
    }
  }

  dailyMoodPass() {
    const average = this.state.survivors.length
      ? Math.round(this.state.survivors.reduce((sum, s) => sum + s.morale, 0) / this.state.survivors.length)
      : 0;
    this.state.stats.morale = clamp(Math.round((this.state.stats.morale + average) / 2), 0, 100);
  }

  nextDay() {
    this.state.day += 1;
    this.processFood();
    this.processAssignments();
    this.processInfections();
    this.processAttacks();
    this.cleanupDeaths();
    this.dailyMoodPass();
    this.recalculateDefense();

    if (chance(0.2)) {
      this.state.resources.energy = clamp(this.state.resources.energy + randInt(1, 3), 0, 999);
      this.addLog('Eski panellerden biraz enerji toplandı.');
    }

    if (chance(0.22) && this.state.resources.meds > 0) {
      this.state.resources.meds -= 1;
      this.addLog('Günlük bakım için ilaç harcandı.');
    }

    this.generateGateCandidate();
    this.save();
    return this.getViewModel();
  }
}
